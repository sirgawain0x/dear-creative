import type { SolanaSigner } from "../types.js";
import type { VersionedTransaction } from "@solana/web3.js";
import { SolanaSignerError } from "./SolanaSignerError.js";

/** Any signer with a `publicKey` and `signTransaction(VersionedTransaction)` method — matches `useWallet()` from `@solana/wallet-adapter-react` and injected wallet providers like `window.phantom.solana`. */
export interface WalletAdapterSigner {
  publicKey: { toBase58(): string };
  signTransaction: <T extends VersionedTransaction>(
    transaction: T,
  ) => Promise<T>;
}

/**
 * Adapts a wallet that signs `VersionedTransaction` objects into a {@link SolanaSigner}.
 *
 * Works with `useWallet()` from `@solana/wallet-adapter-react` and injected
 * browser wallet providers (e.g. `window.phantom.solana`). Handles the
 * `Uint8Array` ↔ `VersionedTransaction` conversion internally.
 *
 * For `@solana/kit` signers, use {@link fromKitSigner}. For raw Ed25519
 * keypairs, use {@link fromKeypair}. For wallet-standard wallets, use
 * {@link fromWalletStandard}.
 *
 * Requires `@solana/web3.js` as a peer dependency.
 *
 * @param {WalletAdapterSigner} signer - The wallet adapter signer
 * @returns {SolanaSigner} A SolanaSigner compatible with `createSmartWalletClient`
 */
export function fromWalletAdapter(signer: WalletAdapterSigner): SolanaSigner {
  return {
    address: signer.publicKey.toBase58(),
    async signTransaction({ transaction }) {
      let tx: VersionedTransaction;
      try {
        const web3 = await import("@solana/web3.js");
        tx = web3.VersionedTransaction.deserialize(transaction);
      } catch (e) {
        throw new SolanaSignerError("Failed to deserialize transaction", {
          cause: e as Error,
        });
      }

      let signed: VersionedTransaction;
      try {
        signed = await signer.signTransaction(tx);
      } catch (e) {
        throw new SolanaSignerError(
          "Wallet adapter failed to sign transaction",
          {
            cause: e as Error,
          },
        );
      }

      return { signedTransaction: new Uint8Array(signed.serialize()) };
    },
  };
}
