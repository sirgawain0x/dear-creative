import {
  PrepareCallsCapabilities as PrepareCallsCapabilitiesSchema,
  SendPreparedCallsCapabilities as SendPreparedCallsCapabilitiesSchema,
} from "@alchemy/wallet-api-types/capabilities";
import type { z } from "zod";
import type {
  InnerWalletApiClient,
  InnerSolanaWalletApiClient,
} from "../types.js";

/**
 * Decoded capabilities matching the schema shape (uses `paymasterService` key).
 * `ResolveCapabilities` renames this to `paymaster` for client-facing types.
 */
type DecodedPrepareCallsCaps = z.output<typeof PrepareCallsCapabilitiesSchema>;
type DecodedSendPreparedCallsCaps = z.output<
  typeof SendPreparedCallsCapabilitiesSchema
>;

/**
 * Renames `paymasterService` (RPC) to `paymaster` in a capabilities type. This
 * is because our RPC schema's paymasterService capability does not exactly match
 * the shape of the new spec, so we want to use a different name in our client
 * types to avoid confusion and be compatible with Viem's types.
 */
type ResolveCapabilities<T> = T extends {
  paymasterService?: infer P;
}
  ? Omit<T, "paymasterService"> & { paymaster?: P }
  : T;

export type PrepareCallsCapabilities =
  ResolveCapabilities<DecodedPrepareCallsCaps>;

export type SendPreparedCallsCapabilities =
  ResolveCapabilities<DecodedSendPreparedCallsCaps>;

/**
 * Transforms a type so that any `capabilities` field uses `paymaster`
 * instead of `paymasterService` (RPC).
 */
export type WithCapabilities<T> = T extends {
  capabilities?: infer C;
}
  ? Omit<T, "capabilities"> & {
      capabilities?: ResolveCapabilities<NonNullable<C>>;
    }
  : T;

function hasNoPaymasterField(
  value: object,
): value is DecodedPrepareCallsCaps | DecodedSendPreparedCallsCaps {
  return !("paymaster" in value);
}

function hasNoPaymasterServiceField(
  value: object,
): value is PrepareCallsCapabilities | SendPreparedCallsCapabilities {
  return !("paymasterService" in value);
}

/**
 * Converts capabilities (with `paymaster`) to RPC capabilities (with `paymasterService`)
 * for use with `encode` before sending to the RPC.
 *
 * @param {PrepareCallsCapabilities | SendPreparedCallsCapabilities | undefined} capabilities - Capabilities object containing a `paymaster` field
 * @returns {DecodedPrepareCallsCaps | DecodedSendPreparedCallsCaps | undefined} RPC capabilities with `paymasterService`, or undefined if input is undefined
 */
export function toRpcCapabilities(
  capabilities:
    | PrepareCallsCapabilities
    | SendPreparedCallsCapabilities
    | undefined,
): DecodedPrepareCallsCaps | DecodedSendPreparedCallsCaps | undefined {
  if (!capabilities) return undefined;
  const { paymaster, ...rest } = capabilities;
  const result =
    paymaster !== undefined
      ? { ...rest, paymasterService: paymaster }
      : { ...rest };
  if (hasNoPaymasterField(result)) return result;
  return undefined;
}

/**
 * Converts RPC capabilities (with `paymasterService`) from `decode`
 * to capabilities (with `paymaster`).
 *
 * @param {DecodedPrepareCallsCaps | DecodedSendPreparedCallsCaps | undefined} capabilities - RPC capabilities object containing a `paymasterService` field
 * @returns {PrepareCallsCapabilities | SendPreparedCallsCapabilities | undefined} Capabilities with `paymaster`, or undefined if input is undefined
 */
export function fromRpcCapabilities(
  capabilities:
    | DecodedPrepareCallsCaps
    | DecodedSendPreparedCallsCaps
    | undefined,
): PrepareCallsCapabilities | SendPreparedCallsCapabilities | undefined {
  if (!capabilities) return undefined;
  if ("paymasterService" in capabilities) {
    const { paymasterService, ...rest } = capabilities;
    const result =
      paymasterService !== undefined
        ? { ...rest, paymaster: paymasterService }
        : { ...rest };
    if (hasNoPaymasterServiceField(result)) return result;
    return undefined;
  }
  if (hasNoPaymasterServiceField(capabilities)) return capabilities;
  return undefined;
}

/**
 * Merges client capabilities with capabilities from the request.
 * Uses policyId (singular) when there's one policy, policyIds (array) when multiple.
 *
 * @param {InnerWalletApiClient} client - The inner wallet API client (potentially including global capabilities like policy IDs)
 * @param {T | undefined} capabilities - Request capabilities to merge with, if any
 * @returns {T | undefined} The merged capabilities object, or original capabilities if no capability configuration exists on the client
 */
export const mergeClientCapabilities = <
  T extends PrepareCallsCapabilities | SendPreparedCallsCapabilities,
>(
  client: InnerWalletApiClient,
  capabilities: T | undefined,
): T | undefined => {
  if (!client.policyIds?.length || capabilities?.paymaster) {
    return capabilities;
  }

  return {
    ...capabilities,
    paymaster:
      client.policyIds.length === 1
        ? { policyId: client.policyIds[0] }
        : { policyIds: client.policyIds },
  } as T;
};

export type SolanaPaymasterCapability = {
  policyId: string;
  webhookData?: string;
};

export type SolanaPrepareCallsCapabilities = {
  paymaster?: SolanaPaymasterCapability;
};

/**
 * Merges Solana client-level capabilities (policyId from factory) with
 * request-level capabilities. Request-level takes priority if provided.
 *
 * @param {InnerSolanaWalletApiClient} client - The Solana wallet API client
 * @param {SolanaPrepareCallsCapabilities | undefined} capabilities - Request capabilities to merge with
 * @returns {SolanaPrepareCallsCapabilities | undefined} The merged capabilities
 */
export const mergeSolanaClientCapabilities = (
  client: InnerSolanaWalletApiClient,
  capabilities: SolanaPrepareCallsCapabilities | undefined,
): SolanaPrepareCallsCapabilities | undefined => {
  if (!client.policyIds?.length || capabilities?.paymaster) {
    return capabilities;
  }

  return {
    ...capabilities,
    paymaster: { policyId: client.policyIds[0] },
  };
};

/**
 * Extracts capabilities from prepareCalls that are usable for sendPreparedCalls.
 * Only permissions and paymaster (policyId/policyIds & webhookData) are supported.
 *
 * @param {PrepareCallsCapabilities | undefined} capabilities - The prepareCalls capabilities
 * @returns {SendPreparedCallsCapabilities | undefined} The sendPreparedCalls capabilities, or undefined if no relevant capabilities exist
 */
export const extractCapabilitiesForSending = (
  capabilities: PrepareCallsCapabilities | undefined,
): SendPreparedCallsCapabilities | undefined => {
  if (capabilities?.permissions == null && capabilities?.paymaster == null) {
    return undefined;
  }

  const paymaster = capabilities.paymaster;

  return {
    permissions: capabilities.permissions,
    paymaster:
      paymaster != null
        ? {
            ...("policyId" in paymaster
              ? { policyId: paymaster.policyId }
              : { policyIds: paymaster.policyIds }),
            webhookData: paymaster.webhookData,
          }
        : undefined,
  };
};
