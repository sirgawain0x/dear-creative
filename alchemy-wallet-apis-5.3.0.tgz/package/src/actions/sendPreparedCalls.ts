import type { Prettify } from "viem";
import type { DistributiveOmit, InnerWalletApiClient } from "../types.ts";
import { LOGGER } from "../logger.js";
import {
  mergeClientCapabilities,
  toRpcCapabilities,
  type WithCapabilities,
} from "../utils/capabilities.js";
import { wallet_sendPreparedCalls as MethodSchema } from "@alchemy/wallet-api-types/rpc";
import {
  methodSchema,
  encode,
  decode,
  type MethodParams,
  type MethodResponse,
} from "../utils/schema.js";

const schema = methodSchema(MethodSchema);
type BaseSendPreparedCallsParams = Exclude<
  MethodParams<typeof MethodSchema>,
  { type: "solana-transaction-v0" }
>;
type SendPreparedCallsResponse = MethodResponse<typeof MethodSchema>;

export type SendPreparedCallsParams = Prettify<
  WithCapabilities<
    DistributiveOmit<BaseSendPreparedCallsParams, "chainId"> & {
      chainId?: number;
    }
  >
>;

export type SendPreparedCallsResult = SendPreparedCallsResponse;

/**
 * Sends prepared calls by submitting a signed user operation.
 * This method is used after signing the signature request returned from prepareCalls.
 *
 * @param {InnerWalletApiClient} client - The wallet API client to use for the request
 * @param {SendPreparedCallsParams} params - Parameters for sending prepared calls
 * @returns {Promise<SendPreparedCallsResult>} A Promise that resolves to the result containing the call ID
 *
 * @example
 * ```ts
 * // First prepare the calls
 * const preparedCalls = await client.prepareCalls({
 *   calls: [{
 *     to: "0x1234...",
 *     data: "0xabcdef...",
 *     value: 0n
 *   }],
 *   capabilities: {
 *     paymaster: { policyId: "your-policy-id" }
 *   }
 * });
 *
 * // Then sign the calls
 * const signedCalls = await client.signPreparedCalls(preparedCalls);
 *
 * // Then send the prepared calls with the signature
 * const result = await client.sendPreparedCalls({
 *   signedCalls,
 * });
 * ```
 */
export async function sendPreparedCalls(
  client: InnerWalletApiClient,
  params: SendPreparedCallsParams,
): Promise<SendPreparedCallsResult> {
  const capabilities = mergeClientCapabilities(client, params.capabilities);

  LOGGER.debug("sendPreparedCalls:start", { type: params.type });

  const { chainId: rawChainId, ...restParams } = params;
  const chainId = rawChainId ?? client.chain.id;

  const fullParams =
    restParams.type === "array"
      ? { ...restParams, capabilities: toRpcCapabilities(capabilities) }
      : {
          ...restParams,
          chainId,
          capabilities: toRpcCapabilities(capabilities),
        };

  const rpcParams = encode(schema.request, fullParams);

  const rpcResp = await client.request({
    method: "wallet_sendPreparedCalls",
    params: [rpcParams],
  });

  LOGGER.debug("sendPreparedCalls:done");
  return decode(schema.response, rpcResp);
}
