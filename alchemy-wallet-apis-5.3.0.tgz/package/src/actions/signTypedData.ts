import { type Address as ViemAddress, type Hex, type TypedData } from "viem";
import type { InnerWalletApiClient } from "../types.ts";
import { prepareSign } from "./prepareSign.js";
import { signSignatureRequest } from "./signSignatureRequest.js";
import { formatSign } from "./formatSign.js";
import { typedDataToJsonSafe } from "../utils/format.js";
import { LOGGER } from "../logger.js";
import { resolveAddress, type AccountParam } from "../utils/resolve.js";

export type SignTypedDataParams = {
  domain?: {
    name?: string;
    version?: string;
    chainId?: number | bigint;
    verifyingContract?: ViemAddress;
    salt?: Hex;
  };
  types: TypedData | Record<string, unknown>;
  primaryType: string;
  message: Record<string, unknown>;
  account?: AccountParam;
};

export type SignTypedDataResult = Hex;

/**
 * Signs typed data (EIP-712) using the smart account.
 * This method requests the account associated with the signer and uses it to sign the typed data.
 *
 * @param {InnerWalletApiClient} client - The wallet API client to use for the request
 * @param {TypedDataDefinition} params - The typed data to sign, following EIP-712 format
 * @returns {Promise<SignTypedDataResult>} A Promise that resolves to the signature as a hex string
 *
 * @example
 * ```ts
 * // Sign typed data
 * const signature = await client.signTypedData({
 *   domain: {
 *     name: 'Example DApp',
 *     version: '1',
 *     chainId: 1,
 *     verifyingContract: '0xCcCCccccCCCCcCCCCCCcCcCccCcCCCcCcccccccC'
 *   },
 *   types: {
 *     Person: [
 *       { name: 'name', type: 'string' },
 *       { name: 'wallet', type: 'address' }
 *     ]
 *   },
 *   primaryType: 'Person',
 *   message: {
 *     name: 'John Doe',
 *     wallet: '0xAaAaAaAaAaAaAaAaAaAAAAAAAAaaaAaAaAaaAaAa'
 *   }
 * });
 * ```
 */

export async function signTypedData(
  client: InnerWalletApiClient,
  params: SignTypedDataParams,
): Promise<SignTypedDataResult> {
  LOGGER.debug("signTypedData:start", {
    hasExplicitAccount: params.account != null,
    primaryType: params.primaryType,
  });
  const accountAddress = params.account
    ? resolveAddress(params.account)
    : client.account.address;

  const prepared = await prepareSign(client, {
    account: accountAddress,
    signatureRequest: {
      type: "eth_signTypedData_v4",
      data: typedDataToJsonSafe(params),
    },
  });

  const signed = await signSignatureRequest(client, prepared.signatureRequest);

  const formatted = await formatSign(client, {
    account: accountAddress,
    signature: {
      type: "ecdsa",
      data: signed.data,
    },
  });
  LOGGER.debug("signTypedData:done", { from: accountAddress });
  return formatted.signature;
}
